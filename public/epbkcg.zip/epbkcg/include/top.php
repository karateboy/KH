<div class="top"><div class="min-box">
<ul class="top-bnt">
<li><a class="acca" href="index.php" accesskey="U" title=":::(上方區塊)">:::</a></li>
<li><a id="item-101" href="" title="回首頁">回首頁</a></li>
<li><a id="item-102" href="" title="友善連結">友善連結</a></li>
<li><a id="item-103" href="" title="交通位置">交通位置</a></li>
<li><a id="item-104" href="" title="網站導覽">網站導覽</a></li>
</ul>
</div></div>

<div class="header">
<div class="logo"><a href="index.php"><img src="images/master/logo.png" title="高雄市政府環境保護局" alt="高雄市政府環境保護局"></a></div>

<ul class="menu_box">
<li><a id="menu01" href="" title="法規介紹"></a></li>
<li><a id="menu02" href="" title="來源介紹"></a></li>
<li><a id="menu03" href="" title="管制策略"></a></li>
<li><a id="menu04" href="" title="宣導資訊"></a></li>
<li><a id="menu05" href="" title="資料庫"></a>

<ul>
<li><a href="" title="一般民眾">一般民眾</a></li>
<li><a href="" title="管理單位" target="_blank">管理單位</a></li>
</ul>

</li>
</ul>
</div>